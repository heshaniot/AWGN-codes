subplot(211)
semilogy(Results.EbNo,Results.FER);
hold on;
    
subplot(212)
semilogy(Results.EbNo,Results.BER);
hold on;